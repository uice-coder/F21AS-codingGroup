package simulation;

import model.Manager;
import model.Order;

import javax.swing.SwingUtilities;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Central controller for the Stage 2 simulation (MVC Controller).
 * Manages the CustomerQueue, ServerWorker threads, and CustomerProducer.
 * Also acts as the Observable subject in the Observer pattern.
 */
public class SimulationController {

    private final Manager manager;
    private final CustomerQueue queue = new CustomerQueue();
    private final List<ServerWorker> staff = new ArrayList<>();
    private CustomerProducer producer;

    private final List<SimulationObserver> observers = new ArrayList<>();

    private volatile boolean running = false;
    private int    numStaff       = 2;
    private double speedMultiplier = 1.0;

    public SimulationController(Manager manager) {
        this.manager = manager;
    }

    // ── Observer pattern ──────────────────────────────────────────────────────

    public void addObserver(SimulationObserver obs) {
        observers.add(obs);
    }

    public synchronized void notifyObservers() {
        for (SimulationObserver obs : observers) {
            SwingUtilities.invokeLater(obs::onSimulationUpdate);
        }
    }

    // ── Simulation lifecycle ──────────────────────────────────────────────────

    public void startSimulation() {
        if (running) return;
        running = true;

        List<Order> orders = new ArrayList<>(manager.getOrders());
        SimulationLog.getInstance().log("Simulation started with "
                + numStaff + " staff and " + orders.size() + " orders.");

        // Start server threads
        staff.clear();
        for (int i = 1; i <= numStaff; i++) {
            ServerWorker s = new ServerWorker(i, queue, this);
            s.setSpeedMultiplier(speedMultiplier);
            staff.add(s);
            s.start();
        }

        // Start producer thread
        producer = new CustomerProducer(orders, queue);
        producer.setSpeedMultiplier(speedMultiplier);
        producer.start();

        // Monitor thread: waits for all work to finish, then shuts down
        Thread monitor = new Thread(() -> {
            try {
                producer.join();
                for (ServerWorker s : new ArrayList<>(staff)) s.join();
            } catch (InterruptedException ignored) {}
            running = false;
            SimulationLog.getInstance().log("=== Simulation complete. Coffee shop closing. ===");
            String report = manager.generateSalesReport();
            SimulationLog.getInstance().log(report);
            SimulationLog.getInstance().writeToFile("simulation_log.txt");
            notifyObservers();
        }, "SimulationMonitor");
        monitor.setDaemon(true);
        monitor.start();
    }

    // ── Staff management (Extension 2) ───────────────────────────────────────

    /** Add a new server thread while simulation is running. */
    public void addStaff() {
        if (!running) return;
        int newId = staff.size() + 1;
        ServerWorker s = new ServerWorker(newId, queue, this);
        s.setSpeedMultiplier(speedMultiplier);
        staff.add(s);
        s.start();
        SimulationLog.getInstance().log("Server " + newId + " added during simulation.");
        notifyObservers();
    }

    /** Remove the last idle server (or last server if none are idle). */
    public void removeStaff() {
        if (!running || staff.isEmpty()) return;
        // Prefer removing an idle worker
        for (int i = staff.size() - 1; i >= 0; i--) {
            ServerWorker s = staff.get(i);
            if (s.getStatus() == ServerWorker.Status.IDLE) {
                staff.remove(i);
                s.stopWorker();
                SimulationLog.getInstance().log("Server " + s.getStaffId()
                        + " removed (was idle).");
                notifyObservers();
                return;
            }
        }
        // Fallback: interrupt the last worker (will finish current order first)
        ServerWorker s = staff.remove(staff.size() - 1);
        s.stopWorker();
        SimulationLog.getInstance().log("Server " + s.getStaffId()
                + " removed (will finish current order).");
        notifyObservers();
    }

    // ── Speed control (Extension 1) ───────────────────────────────────────────

    /**
     * Set simulation speed multiplier.
     * 1.0 = normal, 3.0 = 3× faster, 0.5 = half speed.
     */
    public void setSpeed(double multiplier) {
        this.speedMultiplier = multiplier;
        if (producer != null) producer.setSpeedMultiplier(multiplier);
        for (ServerWorker s : staff) s.setSpeedMultiplier(multiplier);
        SimulationLog.getInstance().log(
                "Simulation speed changed to " + multiplier + "×.");
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public CustomerQueue      getQueue()   { return queue; }
    public List<ServerWorker> getStaff()  { return Collections.unmodifiableList(staff); }
    public boolean            isRunning() { return running; }
    public int                getNumStaff() { return numStaff; }
    public void               setNumStaff(int n) { this.numStaff = n; }
}
