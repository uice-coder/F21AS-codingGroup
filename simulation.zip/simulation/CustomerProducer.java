package simulation;

import model.Order;
import java.util.List;

/**
 * Producer thread: gradually adds customer orders to the CustomerQueue.
 * Represents customers arriving at the coffee shop over time.
 *
 * Inter-arrival delay: 1.5–2.5 seconds (scaled by speedMultiplier).
 */
public class CustomerProducer extends Thread {

    private final List<Order> orders;
    private final CustomerQueue queue;
    private volatile double speedMultiplier = 1.0;

    public CustomerProducer(List<Order> orders, CustomerQueue queue) {
        super("CustomerProducer");
        this.orders = orders;
        this.queue  = queue;
        setDaemon(true);
    }

    @Override
    public void run() {
        for (Order order : orders) {
            if (isInterrupted()) break;
            queue.enqueue(order);
            try {
                long delay = (long)((1500 + (long)(Math.random() * 1000))
                                    / Math.max(0.01, speedMultiplier));
                Thread.sleep(delay);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        queue.close();
        SimulationLog.getInstance().log(
                "All customers have joined the queue. Queue now closed.");
    }

    public void setSpeedMultiplier(double m) { this.speedMultiplier = m; }
}
