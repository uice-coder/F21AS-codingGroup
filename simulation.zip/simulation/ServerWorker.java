package simulation;

import model.Item;
import model.Order;

/**
 * Represents a serving staff member. Runs as a Thread (one per server).
 * Pulls orders from CustomerQueue and processes them with a simulated delay.
 *
 * Processing times (per item):
 *   Beverage : 2–4 seconds
 *   Food     : 6–10 seconds
 *   Other    : 3–5 seconds
 *
 * The speedMultiplier (double) scales all sleep times:
 *   1.0 = normal, 3.0 = 3× faster, 0.5 = half speed.
 */
public class ServerWorker extends Thread {

    public enum Status { IDLE, PROCESSING, DONE }

    private final int staffId;
    private final CustomerQueue queue;
    private final SimulationController controller;

    private volatile Status status       = Status.IDLE;
    private volatile Order  currentOrder = null;
    private volatile double speedMultiplier = 1.0;
    private volatile boolean stopRequested  = false;

    public ServerWorker(int staffId, CustomerQueue queue, SimulationController controller) {
        super("ServerWorker-" + staffId);
        this.staffId    = staffId;
        this.queue      = queue;
        this.controller = controller;
        setDaemon(true);
    }

    @Override
    public void run() {
        SimulationLog.getInstance().log("Server " + staffId + " is ready.");
        try {
            while (!stopRequested) {
                Order order = queue.dequeue();
                if (order == null || stopRequested) break; // queue closed & empty, or removed
                processOrder(order);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        status       = Status.DONE;
        currentOrder = null;
        controller.notifyObservers();
        SimulationLog.getInstance().log("Server " + staffId + " finished work.");
    }

    private void processOrder(Order order) throws InterruptedException {
        currentOrder = order;
        status       = Status.PROCESSING;
        order.calculateFinalPrice();

        SimulationLog.getInstance().log("Server " + staffId
                + " started order " + order.getOrderId()
                + " for customer " + order.getCustomerId());
        controller.notifyObservers();

        long totalMs = calculateProcessingTime(order);
        long scaled  = (long)(totalMs / Math.max(0.01, speedMultiplier));
        Thread.sleep(scaled);

        SimulationLog.getInstance().log("Server " + staffId
                + " COMPLETED order " + order.getOrderId()
                + " for " + order.getCustomerId()
                + String.format(" (£%.2f)", order.getFinalPrice()));

        status       = Status.IDLE;
        currentOrder = null;
        controller.notifyObservers();
    }

    private long calculateProcessingTime(Order order) {
        long ms = 0;
        for (Item item : order.getItems()) {
            String cat = item.getCategory();
            if ("Beverage".equalsIgnoreCase(cat) || "Tea".equalsIgnoreCase(cat)) {
                ms += 2000 + (long)(Math.random() * 2000); // 2–4 s
            } else if ("Food".equalsIgnoreCase(cat)) {
                ms += 6000 + (long)(Math.random() * 4000); // 6–10 s
            } else {
                ms += 3000 + (long)(Math.random() * 2000); // 3–5 s (Other)
            }
        }
        return Math.max(2000, ms);
    }

    /** Signals this worker to stop after its current order finishes. */
    public void stopWorker() {
        stopRequested = true;
        interrupt(); // wake up if blocked in dequeue()
    }

    public int     getStaffId()       { return staffId; }
    public Status  getStatus()        { return status; }
    public Order   getCurrentOrder()  { return currentOrder; }
    public void    setSpeedMultiplier(double m) { this.speedMultiplier = m; }
}
